package com.mypackage.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.model.Role;
import com.mypackage.model.User;
import com.mypackage.model.UserCompletedTraining;
import com.mypackage.model.UserCurrentTraining;
import com.mypackage.model.UserDetails;
import com.mypackage.repository.RoleRepository;
import com.mypackage.repository.UserCompletedRepository;
import com.mypackage.repository.UserCurrentRepository;
import com.mypackage.repository.UserRepository;
import com.mypackage.repository.UserSignupRepository;
@Service
public class UserService {
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserSignupRepository usersignupRepository;
	@Autowired
	private UserCurrentRepository usercurrentRepository;
	@Autowired
	private UserCompletedRepository usercompletedRepository;
	
	public void saveRole(Role r) {
		roleRepository.save(r);
		
	}
	public void saveUser(User u) {
		userRepository.save(u);
	}
//	public void saveUser(String username,String password) {
//		User u=new User();
//		u.setUsername(username);
//		u.setPassword(password);
//		int id=1;
//		Role r=roleRepository.findById(id);
//		u.setRole(r);
//		
//		userRepository.save(u);
//		
//	}
	public void saveUserSignup(UserDetails u) {
		usersignupRepository.save(u);
}
	public User findUser(String username) {
		return userRepository.findByUsername(username);
	}
//	public List<UserCurrentTraining> searchCurrent(String username) {
//		User u=userRepository.findByUsername(username);
//		
//		
//		return usercurrentRepository.findByUsername(u);
//		
//	}
//	@GetMapping("/findcompleted/{username}")
//	public @ResponseBody List<MentorCompletedTraining>  findcompleted(@PathVariable String username){
//		
//return mentorservice.searchCompleted(username);
//	}

	public List<UserCompletedTraining> searchCompleted() {
		
		
		return (List<UserCompletedTraining>) usercompletedRepository.findAll();
		
	}
public List<UserCurrentTraining> searchCurrent() {
		
		
		return (List<UserCurrentTraining>) usercurrentRepository.findAll();
		
	}

}
