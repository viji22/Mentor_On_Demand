package com.mypackage.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mypackage.model.UserDetails;
@Repository
public interface UserSignupRepository extends CrudRepository<UserDetails, String> {

}
