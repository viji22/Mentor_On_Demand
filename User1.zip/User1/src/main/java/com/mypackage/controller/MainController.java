package com.mypackage.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mypackage.model.Role;
import com.mypackage.model.User;
import com.mypackage.model.UserCompletedTraining;
import com.mypackage.model.UserCurrentTraining;
import com.mypackage.model.UserDetails;
import com.mypackage.repository.RoleRepository;
import com.mypackage.service.UserService;


@Controller    
@CrossOrigin(origins="http://localhost:4200")  
public class MainController {
	@Autowired
	private UserService userService;
	@Autowired
	private RoleRepository roleRepository;
	@PostMapping(path="/role")
	public @ResponseBody String role(@RequestBody Role r) {
		userService.saveRole(r);
		return "saved";
		
	}
//	@GetMapping(path="/user/{username}/{password}")
//	public @ResponseBody String user(@PathVariable String username,@PathVariable String password) {
//		
//		userService.saveUser(username,password);
//		return "saved";
//		
//		
//	}
	@PostMapping("/save")
	public @ResponseBody String saveUser(@RequestBody UserDetails u){
		userService.saveUserSignup(u);
		return "stored";
	}
	@PostMapping("/saveuser")
	public @ResponseBody String saveUser(@RequestBody User u){
		userService.saveUser(u);
		return "stored";
	}
	@GetMapping("/Completedtraining/findcompleted")
	public @ResponseBody List<UserCompletedTraining>  findcompleted(){
		
     return userService.searchCompleted();
	}
	@GetMapping("/Currenttraining/findcurrent")
	public @ResponseBody List<UserCurrentTraining>  findcurrent(){
		
     return userService.searchCurrent();
	}
	@GetMapping("/finduser/{username}")
	public @ResponseBody User  finduser(@PathVariable String username){
		
return userService.findUser(username);
	}
	
//	@GetMapping("/findcurrent/{username}")
//	public @ResponseBody List<UserCurrentTraining>  findcurrent(@PathVariable String username){
//		
//return userService.searchCurrent(username);
//	}
//	@GetMapping("/findcompleted/{username}")
//	public @ResponseBody List<UserCompletedTraining>  findcompleted(@PathVariable String username){
//		
//return userService.searchCompleted(username);
//	}
}
