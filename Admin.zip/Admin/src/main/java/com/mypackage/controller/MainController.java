package com.mypackage.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mypackage.model.Mentor;
import com.mypackage.model.Payment;
import com.mypackage.model.Technology;
import com.mypackage.model.UserDetails;
import com.mypackage.service.AdminService;


@Controller

public class MainController {
	@Autowired
	private AdminService adminService;
	
	@GetMapping("/findpayment")
	public @ResponseBody  List<Payment> findpayment(){
		return adminService.findPayment();
	}
	@GetMapping("/findadmintechnology")
	public @ResponseBody  List<Technology> findtechnology(){
		return adminService.findTechnology();
	}
	@GetMapping("/finduser")
	public @ResponseBody  List<UserDetails> finduser(){
		return adminService.findUser();
	}
	@GetMapping("/findmentor")
	public @ResponseBody  List<Mentor> findmentor(){
		return adminService.findMentor();
	}
	@GetMapping(path="/user/{username}/{password}")
	public @ResponseBody String user(@PathVariable String username,@PathVariable String password) {
		
		adminService.saveUser(username,password);
		return "saved";
		
	}
	@GetMapping("/savetechnology/{technology}/{duration}")
	public @ResponseBody String savetechnology(@PathVariable String technology,@PathVariable String duration) {
		Technology t=new Technology();
		t.setTechnology(technology);
		t.setDuration(duration);
		
		adminService.savetechnology(t);
		return "stored";
		
	}
	@GetMapping("/userblock/{username}")
	public @ResponseBody String userblock(@PathVariable String username){
		
 adminService.userBlock(username);
 return "deleted";
	}
	@GetMapping("/userunblock/{username}")
	public @ResponseBody String userunblock(@PathVariable String username){
		
 adminService.userUnBlock(username);
 return "added";
	}

}
