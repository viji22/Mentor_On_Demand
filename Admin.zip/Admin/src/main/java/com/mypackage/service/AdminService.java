
package com.mypackage.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mypackage.model.Mentor;
import com.mypackage.model.Payment;
import com.mypackage.model.Role;
import com.mypackage.model.Technology;
import com.mypackage.model.User;
import com.mypackage.model.UserBlock;
import com.mypackage.model.UserDetails;


import com.mypackage.repository.MentorRepository;
import com.mypackage.repository.PaymentRepository;
import com.mypackage.repository.RoleRepository;
import com.mypackage.repository.TechnologyRepository;
import com.mypackage.repository.UserBlockRepository;
import com.mypackage.repository.UserDetailsRepository;
import com.mypackage.repository.UserRepository;

@Service
public class AdminService {
	@Autowired
	private MentorRepository mentorRepository;
	@Autowired
    private PaymentRepository paymentRepository;
	@Autowired
   private RoleRepository roleRepository;
	@Autowired
    private TechnologyRepository technologyRepository;
	@Autowired
    private UserDetailsRepository userDetailsRepository;
	@Autowired
    private UserRepository userRepository;
	@Autowired
	private UserBlockRepository userBlockRepository;
	 public List<Technology> findTechnology(){
		 return (List<Technology>) technologyRepository.findAll();
		 
	 }
	 public List<Payment> findPayment(){
		 return (List<Payment>) paymentRepository.findAll();
		 
	 }
	 public List<UserDetails> findUser(){
		 return (List<UserDetails>) userDetailsRepository.findAll();
		 
	 }
	 public List<Mentor> findMentor(){
		 return (List<Mentor>) mentorRepository.findAll();
		 
	 }
	 public void saveUser(String username,String password) {
			User u=new User();
			u.setUsername(username);
			u.setPassword(password);
			int id=2;
			Role r=roleRepository.findById(id);
			u.setRole(r);
			
			userRepository.save(u);
			
		}
	 public void savetechnology(Technology t) {
			technologyRepository.save(t);
			}
			@Transactional
			public void userBlock(String username) {
				User u=userRepository.findByUsername(username);
				UserBlock ub=new UserBlock();
				ub.setUsername(u.getUsername());
				ub.setPassword(u.getPassword());
				ub.setRole(u.getRole());
				userBlockRepository.save(ub);
				userRepository.deleteByUsername(username);
				
				
			}
			
			
			@Transactional
			public void userUnBlock(String username) {
				
				UserBlock u=userBlockRepository.findByUsername(username);
				User ub=new User();
				ub.setUsername(u.getUsername());
				ub.setPassword(u.getPassword());
				ub.setRole(u.getRole());
				userRepository.save(ub);
				userBlockRepository.deleteByUsername(username);
				
			}
}
