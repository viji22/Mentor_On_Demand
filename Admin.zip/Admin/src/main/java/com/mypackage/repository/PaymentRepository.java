package com.mypackage.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mypackage.model.Payment;

@Repository
public interface PaymentRepository extends CrudRepository<Payment, Integer>{

}
