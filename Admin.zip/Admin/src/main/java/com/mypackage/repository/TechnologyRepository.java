package com.mypackage.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mypackage.model.Technology;

@Repository
public interface TechnologyRepository extends CrudRepository<Technology, Integer> {

}