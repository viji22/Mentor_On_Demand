import { Component, OnInit } from '@angular/core';
import  { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';


@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  loginForm:FormGroup;
  loading:false;
  submitted=false;
  returnUrl:string;


  constructor(
    private formBuilder:FormBuilder,
    private route:ActivatedRoute,
    private router:Router,
    ) { }

  ngOnInit() {
    this.loginForm=this.formBuilder.group({
      username: ['',[Validators.required,Validators.email]],
      password: ['',Validators.required]
    });
    this.returnUrl=this.route.snapshot.queryParams['returnUrl' ]|| '/';
  }

  get f() {return this.loginForm.controls;}

  onSubmit(){
    this.submitted=true;

    if(this.loginForm.invalid){
      return;
    }
    this.router.navigateByUrl('/Admin')
  }
}

