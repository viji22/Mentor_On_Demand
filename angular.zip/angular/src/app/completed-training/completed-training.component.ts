import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
 
import { UserCompletedService } from '../user-completed.service';
import { UserCompleted } from '../user-completed';


@Component({
  selector: 'app-completed-training',
  templateUrl: './completed-training.component.html',
  styleUrls: ['./completed-training.component.css']
})
export class CompletedTrainingComponent implements OnInit {

  usercompleted: Observable<[UserCompleted]>;
 
  constructor(private userCompletedService: UserCompletedService) { }
 
  ngOnInit() {
    this.reloadData();
  }
 
  // deleteCustomers() {
  //   this.userCompletedService.deleteAll()
  //     .subscribe(
  //       data => {
  //         console.log(data);
  //         this.reloadData();
  //       },
  //       error => console.log('ERROR: ' + error));
  // }
 
  reloadData() {
    this.usercompleted = this.userCompletedService.getCompletedTraining();
  }

}
