import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpErrorResponse }from '@angular/common/http';

@Component({
  selector: 'app-technology',
  templateUrl: './technology.component.html',
  styleUrls: ['./technology.component.css']
})
export class TechnologyComponent implements OnInit {

  constructor(private httpservice:HttpClient) { }
  techdetails:string[];

  ngOnInit() {

    this.httpservice.get('../../assets/technology.json').subscribe(

      data=>{
        this.techdetails=data as string[];
      },
      (err :HttpErrorResponse)=>{
        console.log(err.message);
      }
    )
  }

}
