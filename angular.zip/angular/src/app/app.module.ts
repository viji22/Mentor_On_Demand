import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Component } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms'
import { HomeComponent } from './home/home.component';
import { TrainerMenuComponent } from './trainer-menu/trainer-menu.component';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { AdminComponent } from './admin/admin.component';
import { CurrentTrainingComponent } from './current-training/current-training.component';
import { CompletedTrainingComponent } from './completed-training/completed-training.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { SignupUserComponent } from './signup-user/signup-user.component';
import { TrainerDetailsComponent } from './trainer-details/trainer-details.component';
import { TrainerProfileComponent } from './trainer-profile/trainer-profile.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

import { UserComponent } from './user/user.component';
import { TechnologyComponent } from './technology/technology.component';


import { SignupTrainerComponent } from './signup-trainer/signup-trainer.component';
import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import { HttpClientModule } from '@angular/common/http';
import { TrainerLandingPageComponent } from './trainer-landing-page/trainer-landing-page.component';
import { MentorcompletedTrainingComponent } from './mentorcompleted-training/mentorcompleted-training.component';
import { MentorcurrentTrainingComponent } from './mentorcurrent-training/mentorcurrent-training.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TrainerMenuComponent,
    UserMenuComponent,
    AdminComponent,
    CurrentTrainingComponent,
    CompletedTrainingComponent,
    LoginUserComponent,
    SignupUserComponent,
    TrainerDetailsComponent,
    TrainerProfileComponent,
    UserProfileComponent,
   
    UserComponent,
   TechnologyComponent,
   
   
    SignupTrainerComponent,
    EditSkillsComponent,
    TrainerLandingPageComponent,
    MentorcompletedTrainingComponent,
    MentorcurrentTrainingComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
