import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorcompletedTrainingComponent } from './mentorcompleted-training.component';

describe('MentorcompletedTrainingComponent', () => {
  let component: MentorcompletedTrainingComponent;
  let fixture: ComponentFixture<MentorcompletedTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorcompletedTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorcompletedTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
