import { Component, OnInit } from '@angular/core';

import { Observable } from 'rxjs';
 

import { MentorCompletedService } from '../mentor-completed.service';
import { MentorCompleted } from '../mentor-completed';


@Component({
  selector: 'app-mentorcompleted-training',
  templateUrl: './mentorcompleted-training.component.html',
  styleUrls: ['./mentorcompleted-training.component.css']
})
export class MentorcompletedTrainingComponent implements OnInit {
  mentorcompleted: Observable<[MentorCompleted]>;
  constructor(private mentorCompletedService: MentorCompletedService) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.mentorcompleted = this.mentorCompletedService.getCompletedTraining();
  }
}
