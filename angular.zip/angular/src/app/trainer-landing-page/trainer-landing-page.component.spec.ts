import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainerLandingPageComponent } from './trainer-landing-page.component';

describe('TrainerLandingPageComponent', () => {
  let component: TrainerLandingPageComponent;
  let fixture: ComponentFixture<TrainerLandingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrainerLandingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrainerLandingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
