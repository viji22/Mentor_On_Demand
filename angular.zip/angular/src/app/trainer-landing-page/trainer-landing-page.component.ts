import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainer-landing-page',
  templateUrl: './trainer-landing-page.component.html',
  styleUrls: ['./trainer-landing-page.component.css']
})
export class TrainerLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
