import { TestBed } from '@angular/core/testing';

import { TrainerregisterService } from './trainerregister.service';

describe('TrainerregisterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TrainerregisterService = TestBed.get(TrainerregisterService);
    expect(service).toBeTruthy();
  });
});
