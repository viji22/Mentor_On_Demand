import {BrowserModule }from '@angular/platform-browser';
import { NgModule} from '@angular/core';
import {  FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { TrainerMenuComponent } from './trainer-menu/trainer-menu.component';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { AdminComponent } from './admin/admin.component';
import { CurrentTrainingComponent } from './current-training/current-training.component';
import { CompletedTrainingComponent } from './completed-training/completed-training.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { SignupUserComponent } from './signup-user/signup-user.component';
import { TrainerDetailsComponent } from './trainer-details/trainer-details.component';
import { TrainerProfileComponent } from './trainer-profile/trainer-profile.component';
import { UserProfileComponent } from './user-profile/user-profile.component';

import { UserComponent } from './user/user.component';
import { TechnologyComponent } from './technology/technology.component';

import { EditSkillsComponent } from './edit-skills/edit-skills.component';
import { SignupTrainerComponent } from './signup-trainer/signup-trainer.component';
import { TrainerLandingPageComponent } from './trainer-landing-page/trainer-landing-page.component';
import { MentorcurrentTrainingComponent } from './mentorcurrent-training/mentorcurrent-training.component';
import { MentorcompletedTrainingComponent } from './mentorcompleted-training/mentorcompleted-training.component';


const routes: Routes = [{path:'',component:HomeComponent},
{path:'home',component:HomeComponent},
{path:'Trainermenu/:username',component:TrainerMenuComponent},
{path:'Usermenu/:username',component:UserMenuComponent},
{path:'Admin/:username',component:AdminComponent},
{path:'Currenttraining',component:CurrentTrainingComponent},
{path:'Completedtraining',component:CompletedTrainingComponent},
{path:'Loginuser',component:LoginUserComponent},
{path:'Signupuser',component:SignupUserComponent},
{path:'Trainerdetails',component:TrainerDetailsComponent},
{path:'Trainerprofile',component:TrainerProfileComponent},
{path:'Userprofile',component:UserProfileComponent},

{path:'User',component:UserComponent},
{path:'Technology',component:TechnologyComponent},


{path:'Editskills',component:EditSkillsComponent},
{path:'Signuptrainer',component:SignupTrainerComponent},
{path:'Trainerpage',component:TrainerLandingPageComponent},
{path:'Mentorcurrent',component:MentorcurrentTrainingComponent},
  {path:'Mentorcompleted',component:MentorcompletedTrainingComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  
})
export class AppRoutingModule { }
