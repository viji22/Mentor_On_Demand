import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TrainerRegister } from '../trainerregister';
import { TrainerregisterService } from '../trainerregister.service';
import { Role } from '../signup-user/role';
import { Userregister } from '../signup-user/Userregister';
import { Mentor } from './trainersignup';
import { Mentortime } from './mentortime';
import { Mentortechnology } from './trainertechnology';


export class Mentortech{
  id:number;
  technology:string;
}


@Component({
  selector: 'app-signup-trainer',
  templateUrl: './signup-trainer.component.html',
  styleUrls: ['./signup-trainer.component.css']
})
export class SignupTrainerComponent implements OnInit {
 
 role:Role=new Role();
 private id=3;
 private rolename="mentor";

userregister:Userregister=new Userregister();
mentor:Mentor=new Mentor();

// mentortime:Mentortime=new Mentortime();
mentortechnology:Mentortechnology=new Mentortechnology();
private submitted = false;
private error = false;
username:string;
password:string;

firstname:string;
lastname:string;
contactnumber:number;
technology:string;
experience:string;

  constructor(private trainer:TrainerregisterService) { }

  ngOnInit() {
  }
 
 

  save(){
    
    if(this.username==null || this.password==null || this.firstname==null || this.lastname==null
      && this.contactnumber==null || this.technology==null || this.experience==null){
        this.error=true;
      }
    else{
    this.mentor.username=this.username;
    this.mentor.firstname=this.firstname;
    this.mentor.lastname=this.lastname;
    this.mentor.contactnumber=this.contactnumber;
    this.mentor.technology=this.technology
    this.mentor.experience=this.experience;
    this.userregister.password=this.password;
    this.userregister.username=this.username;
    this.role.id=this.id;
    this.role.role=this.rolename;
    this.userregister.role=this.role;

    this.trainer.createMentor(this.mentor)
    .subscribe(data => console.log(data), error => console.log(error));

    this.userregister.password=this.password;
    this.userregister.username=this.username;
    this.trainer.createUserRegister(this.userregister)
    .subscribe(data => console.log(data), error => console.log(error));
  
   this.submitted=true;
   
   this.error=false;
    }
    
  }
 
}


