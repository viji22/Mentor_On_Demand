export class Mentor{
    username:string;
    contactnumber:number;
    experience:string;
    
    firstname:string;
    lastname:string;
    technology:string;
}