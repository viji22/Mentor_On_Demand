


import { Mentor } from './trainersignup';

export class Mentortechnology{
    technology:string;
    id:string;
    mentor:string;
}