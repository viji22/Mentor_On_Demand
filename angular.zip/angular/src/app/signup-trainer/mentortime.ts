import { Mentor } from './trainersignup';

export class Mentortime{
    time:string;
    id:string;
    mentor:Mentor;
}