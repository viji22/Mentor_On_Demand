import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorcurrentTrainingComponent } from './mentorcurrent-training.component';

describe('MentorcurrentTrainingComponent', () => {
  let component: MentorcurrentTrainingComponent;
  let fixture: ComponentFixture<MentorcurrentTrainingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorcurrentTrainingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorcurrentTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
