import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { MentorCurrentService } from '../mentor-current.service';
import { MentorCurrent } from '../mentor-current';

@Component({
  selector: 'app-mentorcurrent-training',
  templateUrl: './mentorcurrent-training.component.html',
  styleUrls: ['./mentorcurrent-training.component.css']
})
export class MentorcurrentTrainingComponent implements OnInit {
  mentorcurrent: Observable<[MentorCurrent]>;
  
  constructor(private mentorCurrentService: MentorCurrentService) { }


  ngOnInit() {
   

      this.reloadData();
    }
    reloadData() {
      this.mentorcurrent = this.mentorCurrentService.getCurrentTraining();
    }
  }