export class MentorCompleted {
    username: string;
    technology: string;
    duration: number;
}