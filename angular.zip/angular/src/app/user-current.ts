export class UserCurrent{
    id:Int16Array;
    technology: string;
    completedduration:string;
    remainingduration:string;
}
			