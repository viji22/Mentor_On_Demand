import { TestBed } from '@angular/core/testing';

import { UserregisterserviceService } from './userregisterservice.service';

describe('UserregisterserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserregisterserviceService = TestBed.get(UserregisterserviceService);
    expect(service).toBeTruthy();
  });
});
