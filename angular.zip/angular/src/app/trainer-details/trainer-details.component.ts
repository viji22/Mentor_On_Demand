import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-trainer-details',
  templateUrl: './trainer-details.component.html',
  styleUrls: ['./trainer-details.component.css']
})
export class TrainerDetailsComponent implements OnInit {

  constructor(private httpservice:HttpClient) { }
  course:string[];

  ngOnInit() {
    this.httpservice.get('../../assets/data.json').subscribe(
      data=>{
        this.course=data as string[];
      },
      (err :HttpErrorResponse)=>{
        console.log(err.message);

      }
    )

    
  }
}



