export class UserCompleted {
    username: string;
    technology: string;
    duration: number;
}