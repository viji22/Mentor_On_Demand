export class MentorCurrent{
    id:Int16Array;
    completedduration:string;
    pendingduration:string;
    technology: string;
    username:string;
}
	