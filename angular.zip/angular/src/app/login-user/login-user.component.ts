import { Component, OnInit } from '@angular/core';
import  { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Userregister } from '../signup-user/Userregister';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {
  

username:string;
password:string;
invalidLogin :boolean=false;
userlogin:Userregister=new Userregister();
 private error=false;
  constructor(private router:Router,private service:ServiceService) { }

  ngOnInit() {
    
    
  }
  validate(){
    if(this.username==null || this.password==null){
      this.error=true;
      
    }
    
  else{
    this.error=false;
    this.service.getUser(this.username).subscribe(value=>this.userlogin=value);
    if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==1){
    
  this.router.navigate(['/Usermenu',this.username]);
  this.invalidLogin = false;
    }
    else if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==3){
    
        this.router.navigate(['/Trainermenu',this.username]);
        this.invalidLogin = false;
          }
          else  if(this.userlogin.username==this.username && this.userlogin.password==this.password && this.userlogin.role.id==2){
    
            this.router.navigate(['/Admin',this.username]);
            this.invalidLogin = false;
              }
          
else{
  this.invalidLogin=true;
}
    }
  }
  

  }
  
