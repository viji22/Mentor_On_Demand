import { Component, OnInit } from '@angular/core';
import { UserCurrentService } from '../user-current.service';
import { Observable } from 'rxjs';
import { UserCurrent } from '../user-current';
@Component({
  selector: 'app-current-training',
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {

  usercurrent: Observable<[UserCurrent]>;
  

  constructor(private userCurrentService: UserCurrentService) { }

  ngOnInit() {

    this.reloadData();
  }
  reloadData() {
    this.usercurrent = this.userCurrentService.getCurrentTraining();
  }
}
