import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
export class User{
  constructor(
    public status:string,
     ) {}
  
}
@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  private baseUrl = 'http://localhost:8080/api'; 
   

  constructor(private http:HttpClient) { }
  getUser(username:string):Observable<any> {  
    return this.http.get(`http://localhost:8080/api/User1/finduser/${username}`);  
  }
  searchMentor(technology:string):Observable<any> {  
    return this.http.get(`${this.baseUrl}/Course/findtechnology/${technology}`);  
  }
  getPayment(){
    return this.http.get(`${this.baseUrl}/Admin/findpayment`);

  }
  getTechnology():Observable<any> {  
    return this.http.get(`${this.baseUrl}/Admin/findadmintechnology`);  
  }
  addtechnology(technology:string,duration:string){
    return this.http.get(`${this.baseUrl}/Admin/savetechnology/${technology}/${duration}`);

  }
  userblock(username:string){
    return this.http.get(`${this.baseUrl}/Admin/userblock/${username}`);

  }
  userunblock(username:string){
    return this.http.get(`${this.baseUrl}/Admin/userunblock/${username}`);

  }
  getUse(){  
    return this.http.get(`${this.baseUrl}/Admin/finduser`);  
  }
  getMentor() {  
    return this.http.get(`${this.baseUrl}/Admin/findmentor`);  
  }
  findMentor():Observable<any> {  
    return this.http.get(`${this.baseUrl}/Course/findmentorlist/`);  
  }
 
 
}
