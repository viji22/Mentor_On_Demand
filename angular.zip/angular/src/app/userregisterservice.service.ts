import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class UserregisterserviceService {
  
 
  
  constructor(private http: HttpClient){}

  
  createUser(user:object):Observable<object>{
    return this.http.post(`http://localhost:8080/api/User1/save`,user);
  }

   
  createUserRegister(userregister:object):Observable<object>{
    return this.http.post(`http://localhost:8080/api/User1/saveuser`,userregister);
  }
}
