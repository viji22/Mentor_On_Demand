import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpErrorResponse }from '@angular/common/http';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor( private httpservice:HttpClient) { }
  identifier:string[];

  ngOnInit() {
    this.httpservice.get('../../assets/user.json').subscribe(

      data=>{
        this.identifier=data as string[];
      },
      (err :HttpErrorResponse)=>{
        console.log(err.message);
      }
    )
  }

}
