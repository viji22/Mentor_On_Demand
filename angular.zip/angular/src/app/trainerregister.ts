

export class TrainerRegister{
    username:string;
    password:string;
    firstname:string;
    lastname:string;
   contactnumber:number;
    experience:Int16Array;
    technology:string;
}

	
	