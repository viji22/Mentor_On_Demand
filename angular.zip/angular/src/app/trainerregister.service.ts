import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TrainerregisterService {

  constructor(private http:HttpClient) { }

  
  createMentor(mentor:object):Observable<object>{
    return this.http.post(`http://localhost:8080/api/Trainer1/save`,mentor);
  }

   
  createUserRegister(userregister:object):Observable<object>{
    return this.http.post(`http://localhost:8080/api/Trainer1/savementor`,userregister);
  }

getCompleted(username: string) {  
  return this.http.get(`http://localhost:8080/api/Trainer1/findcompleted/${username}`);  
}
  getCurrent(username:string) {  
  return this.http.get(`http://localhost:8080/api/Trainer1/findcurrent/${username}`);  
}
}
