import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-user-menu',
  templateUrl: './user-menu.component.html',
  styleUrls: ['./user-menu.component.css']
})
export class UserMenuComponent implements OnInit {
  displayvalue: boolean=false;
  mentor: string[];

  constructor(private trainer:ServiceService) { }

  ngOnInit() {
  }
  showsearch(){
    this.displayvalue=true;
      this.trainer.findMentor()
      .subscribe(data =>this.mentor=data as string[]);
      
      
    }
    
}
