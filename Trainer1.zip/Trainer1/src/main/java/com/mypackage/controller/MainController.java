package com.mypackage.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;


import com.mypackage.model.Mentor;
import com.mypackage.service.MentorService;
import com.mypackage.model.MentorCompletedTraining;
import com.mypackage.model.MentorCurrentTraining;
import com.mypackage.model.User;

import com.mypackage.repository.RoleRepository;


@Controller    
@CrossOrigin(origins="http://localhost:4200")  
public class MainController {
	@Autowired
	private MentorService mentorService;
	@Autowired
	private RoleRepository roleRepository;
	
	@PostMapping("/save")
	public @ResponseBody String saveUser(@RequestBody Mentor m){
		mentorService.saveMentorDetails(m);
		return "stored";
	}
	
//	@GetMapping(path="/saveuser/{username}/{password}")
//	public @ResponseBody String user(@PathVariable String username,@PathVariable String password) {
//		
//		mentorService.saveUser(username,password);
//		return "saved";
//		
//	}
	@PostMapping("/savementor")
	public @ResponseBody String savementor(@RequestBody User u){
		mentorService.saveMentor(u);
		return "stored";
	}
	

	@GetMapping("/Mentorcompleted/findcompleted")
	public @ResponseBody List<MentorCompletedTraining>  findcompleted(){
		
return mentorService.searchCompleted();
	}
	@GetMapping("/Mentorcurrent/findcurrent")
	public @ResponseBody List<MentorCurrentTraining>  findcurrent(){
		
return mentorService.searchCurrent();
	}
	
		

	}
	
//	@GetMapping("/findcompleted/{username}")
//	public @ResponseBody List<MentorCompletedTraining>  findcompleted(@PathVariable String username){
//		
//return mentorService.searchCompleted(username);
//	}
//	@GetMapping("/findcurrent/{username}")
//	public @ResponseBody List<MentorCurrentTraining>  findcurrent(@PathVariable String username){
//		
//return mentorService.searchCurrent(username);
//	}
	
	


