package com.mypackage.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mypackage.model.MentorCurrentTraining;
import com.mypackage.model.User;

@Repository
public interface MentorCurrentTrainingRepository extends CrudRepository<MentorCurrentTraining, Integer>{

	List<MentorCurrentTraining> findByUsername(User u);

}