package com.mypackage.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import com.mypackage.model.Mentor;
import com.mypackage.model.Role;
import com.mypackage.model.User;

import com.mypackage.model.MentorCompletedTraining;
import com.mypackage.model.MentorCurrentTraining;



import com.mypackage.repository.MentorRepository;

import com.mypackage.repository.RoleRepository;
import com.mypackage.repository.UserRepository;
import com.mypackage.repository.MentorCompletedTrainingRepository;
import com.mypackage.repository.MentorCurrentTrainingRepository;
@Service
public class MentorService {
	@Autowired
	private MentorRepository mentorRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private MentorCompletedTrainingRepository mentorCompletedRepository;
	@Autowired
	private MentorCurrentTrainingRepository mentorCurrentRepository;
	
	public void saveMentorDetails(Mentor m) {
		mentorRepository.save(m);
		
	}

	
		public void saveMentor(User u) {
			userRepository.save(u);
			
			
		}
	
	
//	public void saveUser(String username,String password) {
//		User u=new User();
//		u.setUsername(username);
//		u.setPassword(password);
//		int id=3;
//		Role r=roleRepository.findById(id);
//		u.setRole(r);
//		
//		userRepository.save(u);
//		}
//	public List<MentorCompletedTraining> searchCompleted(String username) {
//		User u=userRepository.findByUsername(username);
//		
//		
//		return mentorCompletedRepository.findByUsername(u);
//		
//	}
public List<MentorCompletedTraining> searchCompleted() {
		
		
		return (List<MentorCompletedTraining>) mentorCompletedRepository.findAll();
		
	}
public List<MentorCurrentTraining> searchCurrent() {
	
	
	return (List<MentorCurrentTraining>) mentorCurrentRepository.findAll();
	
}

	
	
	

}
